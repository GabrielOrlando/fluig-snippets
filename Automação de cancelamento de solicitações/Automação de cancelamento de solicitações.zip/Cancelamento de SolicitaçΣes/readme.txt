
	--- cancelamento.js ---
- Depende do dsCancelamentos.js para funcionar.
- Necessita alterar o <processId> para o processo desejado.
- Usu�rio logado precisa ser gestor do processo.

-> Atendendo os itens acima, vai cancelar todas as solicita��es abertas para o processo informado em <processId>.
-> Executar a fun��o no console do navegador.


	--- dsCancelamentos.js ---
-> N�o alterar nada!
-> Apenas exportar para o servidor em quest�o.